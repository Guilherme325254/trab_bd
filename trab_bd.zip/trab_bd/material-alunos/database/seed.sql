PRAGMA foreign_keys = ON;

-- =========================================================
-- CATEGORIAS
-- =========================================================

INSERT INTO categorias (id, nome, descricao) VALUES
(1, 'Hatch', 'Carros compactos e econômicos'),
(2, 'Sedan', 'Carros sedan para uso urbano e viagens'),
(3, 'SUV', 'Veículos utilitários esportivos'),
(4, 'Picapes', 'Veículos para transporte e trabalho'),
(5, 'Esportivos', 'Carros de alto desempenho');


-- =========================================================
-- PRODUTOS / CARROS
-- =========================================================

INSERT INTO produtos
(id, nome, descricao, preco, estoque, imagem_url, categoria_id)
VALUES
(1, 'Volkswagen Polo', 'Hatch compacto, econômico e moderno', 89990.00, 8,
 'https://images.unsplash.com/photo-1541899481282-d53bffe3c35d', 1),

(2, 'Chevrolet Onix', 'Hatch compacto com tecnologia e bom consumo', 82990.00, 10,
 'https://images.unsplash.com/photo-1492144534655-ae79c964c9d7', 1),

(3, 'Fiat Argo', 'Hatch compacto confortável para uso urbano', 79990.00, 7,
 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d', 1),

(4, 'Hyundai HB20', 'Hatch moderno com bom desempenho', 84990.00, 6,
 'https://images.unsplash.com/photo-1503376780353-7e6692767b70', 1),

(5, 'Toyota Corolla', 'Sedan reconhecido pelo conforto e confiabilidade', 159990.00, 5,
 'https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb', 2),

(6, 'Honda Civic', 'Sedan moderno com excelente dirigibilidade', 189990.00, 4,
 'https://images.unsplash.com/photo-1555215695-3004980ad54e', 2),

(7, 'Nissan Sentra', 'Sedan confortável para cidade e estrada', 149990.00, 5,
 'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2', 2),

(8, 'Volkswagen Virtus', 'Sedan espaçoso e tecnológico', 119990.00, 8,
 'https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8', 2),

(9, 'Toyota Corolla Cross', 'SUV urbano confortável e econômico', 179990.00, 6,
 'https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6', 3),

(10, 'Jeep Compass', 'SUV médio com tecnologia e robustez', 169990.00, 5,
 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf', 3),

(11, 'Volkswagen T-Cross', 'SUV compacto versátil para o dia a dia', 139990.00, 7,
 'https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6', 3),

(12, 'Hyundai Creta', 'SUV confortável com amplo espaço interno', 149990.00, 6,
 'https://images.unsplash.com/photo-1519641471654-76ce0107ad1b', 3),

(13, 'Ford Ranger', 'Picape potente para trabalho e aventura', 219990.00, 4,
 'https://images.unsplash.com/photo-1559416523-140ddc3d238c', 4),

(14, 'Toyota Hilux', 'Picape robusta para trabalho e estrada', 229990.00, 3,
 'https://images.unsplash.com/photo-1583121274602-3e2820c69888', 4),

(15, 'Chevrolet S10', 'Picape versátil com grande capacidade de carga', 199990.00, 4,
 'https://images.unsplash.com/photo-1605559424843-9e4c228bf1c1', 4),

(16, 'Fiat Toro', 'Picape urbana com conforto de SUV', 149990.00, 8,
 'https://images.unsplash.com/photo-1502877338535-766e1452684a', 4),

(17, 'Ford Mustang', 'Esportivo de alta performance', 499990.00, 2,
 'https://images.unsplash.com/photo-1584345604476-8ec5e12e42dd', 5),

(18, 'Chevrolet Camaro', 'Esportivo potente com design marcante', 459990.00, 2,
 'https://images.unsplash.com/photo-1553440569-bcc63803a83d', 5),

(19, 'Porsche 911', 'Esportivo premium de alto desempenho', 899990.00, 1,
 'https://images.unsplash.com/photo-1503736334956-4c8f8e92946d', 5),

(20, 'BMW M4', 'Esportivo premium com excelente desempenho', 699990.00, 2,
 'https://images.unsplash.com/photo-1555215695-3004980ad54e', 5);


-- =========================================================
-- CLIENTES
-- =========================================================

INSERT INTO clientes
(id, nome, email, senha, endereco)
VALUES
(1, 'João Silva', 'joao@email.com', '123456',
 'Rua das Flores, 100 - Rio de Janeiro/RJ'),

(2, 'Maria Oliveira', 'maria@email.com', '123456',
 'Av. Brasil, 250 - São Paulo/SP'),

(3, 'Carlos Santos', 'carlos@email.com', '123456',
 'Rua Central, 500 - Belo Horizonte/MG'),

(4, 'Ana Costa', 'ana@email.com', '123456',
 'Rua Paraná, 80 - Curitiba/PR'),

(5, 'Pedro Almeida', 'pedro@email.com', '123456',
 'Av. Atlântica, 900 - Rio de Janeiro/RJ');


-- =========================================================
-- CUPONS
-- =========================================================

INSERT INTO cupons
(id, codigo, tipo_desconto, valor, validade, ativo)
VALUES
(1, 'CARRO10', 'percentual', 10, '2027-12-31', 1),

(2, 'AUTO5000', 'fixo', 5000, '2027-12-31', 1),

(3, 'MOTOR20', 'percentual', 20, '2027-11-30', 1);


-- =========================================================
-- PEDIDOS
-- =========================================================

INSERT INTO pedidos
(id, cliente_id, cupom_id, status, endereco_entrega,
 subtotal, desconto, total, criado_em)
VALUES

(1, 1, 1, 'entregue',
 'Rua das Flores, 100 - Rio de Janeiro/RJ',
 89990.00, 8999.00, 80991.00,
 '2026-09-05 10:30:00'),

(2, 2, NULL, 'entregue',
 'Av. Brasil, 250 - São Paulo/SP',
 159990.00, 0, 159990.00,
 '2026-09-10 14:20:00'),

(3, 3, 2, 'enviado',
 'Rua Central, 500 - Belo Horizonte/MG',
 169990.00, 5000.00, 164990.00,
 '2026-09-15 09:45:00'),

(4, 4, 3, 'pago',
 'Rua Paraná, 80 - Curitiba/PR',
 149990.00, 29998.00, 119992.00,
 '2026-09-20 16:10:00'),

(5, 5, NULL, 'pendente',
 'Av. Atlântica, 900 - Rio de Janeiro/RJ',
 499990.00, 0, 499990.00,
 '2026-09-25 11:00:00');


-- =========================================================
-- ITENS DOS PEDIDOS
-- =========================================================

INSERT INTO itens_pedido
(id, pedido_id, produto_id, quantidade, preco_unitario)
VALUES

-- Pedido 1 - Volkswagen Polo
(1, 1, 1, 1, 89990.00),

-- Pedido 2 - Toyota Corolla
(2, 2, 5, 1, 159990.00),

-- Pedido 3 - Jeep Compass
(3, 3, 10, 1, 169990.00),

-- Pedido 4 - Hyundai Creta
(4, 4, 12, 1, 149990.00),

-- Pedido 5 - Ford Mustang
(5, 5, 17, 1, 499990.00);


-- =========================================================
-- AVALIAÇÕES
-- =========================================================

INSERT INTO avaliacoes
(id, produto_id, cliente_id, nota, comentario, criado_em)
VALUES

(1, 1, 1, 5,
 'Carro muito econômico e confortável.',
 '2026-09-08 13:20:00'),

(2, 2, 2, 4,
 'Bom carro para uso diário.',
 '2026-09-09 15:40:00'),

(3, 5, 2, 5,
 'Excelente conforto e acabamento.',
 '2026-09-13 10:15:00'),

(4, 10, 3, 4,
 'SUV confortável e potente.',
 '2026-09-14 18:30:00'),

(5, 12, 3, 5,
 'Muito espaço e ótimo desempenho.',
 '2026-09-18 09:00:00'),

(6, 13, 4, 5,
 'Picape muito forte para trabalho.',
 '2026-09-19 12:45:00'),

(7, 14, 4, 4,
 'Excelente capacidade e conforto.',
 '2026-09-23 16:20:00'),

(8, 17, 5, 5,
 'Carro incrível e muito potente.',
 '2026-09-24 11:10:00'),

(9, 18, 5, 4,
 'Design muito bonito e ótimo desempenho.',
 '2026-09-28 14:50:00'),

(10, 19, 5, 5,
 'Experiência excelente ao dirigir.',
 '2026-09-29 17:25:00');